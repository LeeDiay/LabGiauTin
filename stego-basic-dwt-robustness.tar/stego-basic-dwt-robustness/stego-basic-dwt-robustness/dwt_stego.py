import numpy as np
from PIL import Image
import pywt
import cv2

def text_to_binary(text):
    # Chuyen van ban sang dang nhi phan
    binary = ''.join(format(ord(char), '08b') for char in text)
    return binary

def binary_to_text(binary):
    # Chuyen nhi phan ve van ban
    text = ''
    binary = binary[:len(binary) - len(binary) % 8]
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        if len(byte) == 8:
            text += chr(int(byte, 2))
    return text

def embed_message(image_path, message, output_path):
    # Doc anh xam
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError("Khong the doc anh")

    # Chuyen thong diep sang nhi phan
    binary_message = text_to_binary(message)
    message_length = len(binary_message)
    binary_length = format(message_length, '032b')

    # Bien doi DWT
    coeffs = pywt.dwt2(img, 'haar')
    cA, (cH, cV, cD) = coeffs

    # Nhung thong diep vao he so cH
    cH_flat = cH.flatten()
    if len(cH_flat) < message_length + 32:
        raise ValueError("Anh qua nho de chua thong diep!")

    # Nhung do dai thong diep (32 bit dau)
    for i in range(32):
        cH_flat[i] = cH_flat[i] + (50 if binary_length[i] == '1' else -50)

    # Nhung thong diep
    for i in range(message_length):
        cH_flat[i + 32] = cH_flat[i + 32] + (50 if binary_message[i] == '1' else -50)

    # Tai tao he so cH
    cH = cH_flat.reshape(cH.shape)

    # Bien doi nguoc DWT
    coeffs_modified = (cA, (cH, cV, cD))
    img_stego = pywt.idwt2(coeffs_modified, 'haar')

    # Luu anh da giau tin
    img_stego = np.clip(img_stego, 0, 255).astype(np.uint8)
    img_stego = Image.fromarray(img_stego)
    img_stego.save(output_path, 'JPEG', quality=100)
    return message_length

def extract_message(image_path):
    # Doc anh xam
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError("Khong the doc anh")

    # Bien doi DWT
    coeffs = pywt.dwt2(img, 'haar')
    _, (cH, _, _) = coeffs

    # Lay he so cH
    cH_flat = cH.flatten()
    if len(cH_flat) < 32:
        raise ValueError("Anh qua nho de trich xuat thong diep!")

    # Trich xuat do dai thong diep (32 bit dau)
    binary_length = ''
    for i in range(32):
        binary_length += '1' if cH_flat[i] >= 0 else '0'
    message_length = int(binary_length, 2)

    # Gioi han do dai thong diep
    max_message_length = len(cH_flat) - 32
    if message_length > max_message_length or message_length < 0:
        print(f"Canh bao: message_length ({message_length}) khong hop le. Gioi han ve {max_message_length}.")
        message_length = max_message_length

    # Trich xuat thong diep
    binary_message = ''
    for i in range(message_length):
        if i + 32 < len(cH_flat):
            binary_message += '1' if cH_flat[i + 32] >= 0 else '0'
        else:
            break

    # Chuyen nhi phan ve van ban
    return binary_to_text(binary_message)

def run_basic_stego(input_image, secret_message, output_image):
    # Chay thuat toan DWT co ban
    print("Bat dau giau tin bang thuat toan DWT va trich xuat thong diep...")
    
    # Nhung thong diep
    message_length = embed_message(input_image, secret_message, output_image)
    print("Da nhung thong diep thanh cong! Do dai thong diep:", message_length)
    
    # Trich xuat thong diep
    extracted_message = extract_message(output_image)
    print("Thong diep trich xuat:", extracted_message)
    return extracted_message

if __name__ == "__main__":
    input_image = "input_image.jpg"
    output_image = "stego.jpg"
    secret_message = "This is a secret message!"
    
    try:
        run_basic_stego(input_image, secret_message, output_image)
    except Exception as e:
        print("Loi:", str(e))