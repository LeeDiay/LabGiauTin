import cv2
import numpy as np
import pywt
import math

# Ham chuyen van ban thanh chuoi bit
def text_to_bits(text):
    bits = ''.join(format(ord(c), '08b') for c in text)
    return bits

# Ham tinh PSNR
def calculate_psnr(img1, img2):
    height1, width1 = img1.shape
    height2, width2 = img2.shape
    min_height = min(height1, height2)
    min_width = min(width1, width2)
    img1 = img1[:min_height, :min_width]
    img2 = img2[:min_height, :min_width]
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel = 255.0
    psnr = 20 * math.log10(max_pixel / math.sqrt(mse))
    return psnr

# Ham giau tin vao subband chi dinh cua DWT cap 2
def embed_message_to_subband(image_path, message, output_path, subband='HH2'):
    print(f"Dang giau tin vao subband {subband}...")
    
    # Doc anh xam
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise Exception("Khong the doc anh")

    # Dam bao kich thuoc anh chia het cho 4
    height, width = img.shape
    if height % 4 != 0 or width % 4 != 0:
        new_height = height - (height % 4)
        new_width = width - (width % 4)
        img = img[:new_height, :new_width]
        print(f"Da cat anh ve kich thuoc ({new_height}, {new_width}) de chia het cho 4")

    # Chuyen sang float32
    img = img.astype(np.float32)

    # Ap dung DWT cap 2
    coeffs1 = pywt.dwt2(img, 'haar')
    cA1, (cH1, cV1, cD1) = coeffs1
    coeffs2 = pywt.dwt2(cA1, 'haar')
    cA2, (cH2, cV2, cD2) = coeffs2

    # Chuyen thong diep thanh bit
    message_bits = text_to_bits(message)
    print(f"Chuoi bit goc (subband {subband}): {message_bits}")
    bit_index = 0

    # Chon subband de nhung
    if subband == 'HH2':
        target_subband = cD2
    elif subband == 'LH2':
        target_subband = cH2
    elif subband == 'HL2':
        target_subband = cV2
    else:
        raise ValueError("Subband khong hop le! Chon 'HH2', 'LH2', hoac 'HL2'")

    # Giau tin vao subband
    target_flat = target_subband.flatten()
    for i in range(len(target_flat)):
        if bit_index < len(message_bits):
            bit = int(message_bits[bit_index])
            target_flat[i] = np.round(target_flat[i])
            if bit == 1:
                target_flat[i] = target_flat[i] + 1.0
            else:
                target_flat[i] = target_flat[i] - 1.0
            bit_index += 1
        else:
            break

    # Kiem tra xem da nhung du thong diep chua
    if bit_index < len(message_bits):
        print(f"Canh bao: Khong du he so wavelet de nhung toan bo thong diep ({bit_index}/{len(message_bits)} bit)")

    # Dua target_flat ve ma tran
    target_subband[:] = target_flat.reshape(target_subband.shape)

    # Tai tao anh tu DWT cap 2
    coeffs2_modified = (cA2, (cH2, cV2, cD2))
    cA1_modified = pywt.idwt2(coeffs2_modified, 'haar')
    coeffs1_modified = (cA1_modified, (cH1, cV1, cD1))
    img_stego = pywt.idwt2(coeffs1_modified, 'haar')

    # Cat khop kich thuoc anh goc
    img_stego = img_stego[:img.shape[0], :img.shape[1]]

    # Dam bao gia tri pixel trong khoang [0, 255]
    img_stego = np.clip(img_stego, 0, 255).astype(np.uint8)

    # Luu anh chua tin
    cv2.imwrite(output_path, img_stego, [cv2.IMWRITE_PNG_COMPRESSION, 0])

    # Tinh PSNR
    psnr = calculate_psnr(img, img_stego)
    print(f"PSNR khi giau tin vao subband {subband}: {psnr:.2f} dB")

# Ham main de chay thu
if __name__ == "__main__":
    image_path = 'input_image_gray.png'  # Duong dan anh goc
    message = "Hello World! I'm PTIT student."  # Thong diep can giau

    # Thu giau tin vao subband LH2
    embed_message_to_subband(image_path, message, 'stego_image_lh2.png', subband='LH2')

    # Thu giau tin vao subband HL2
    embed_message_to_subband(image_path, message, 'stego_image_hl2.png', subband='HL2')