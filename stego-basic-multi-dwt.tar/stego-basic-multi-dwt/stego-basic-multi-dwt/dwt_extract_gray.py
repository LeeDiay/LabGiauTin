import cv2
import numpy as np
import pywt

# Ham chuyen chuoi bit thanh van ban
def bits_to_text(bits):
    try:
        chars = [chr(int(bits[i:i+8], 2)) for i in range(0, len(bits), 8)]
        return ''.join(chars)
    except ValueError:
        return "Loi khi chuyen bit thanh van ban"

# Ham trich xuat thong diep tu subband HH2
def extract_message(stego_image_path, message_length):
    # Doc anh chua tin
    img_stego = cv2.imread(stego_image_path, cv2.IMREAD_GRAYSCALE)
    if img_stego is None:
        raise Exception("Khong the doc anh chua tin")

    # Chuyen sang float32
    img_stego = img_stego.astype(np.float32)

    # Ap dung DWT cap 2
    coeffs1 = pywt.dwt2(img_stego, 'haar')
    cA1, (cH1, cV1, cD1) = coeffs1
    coeffs2 = pywt.dwt2(cA1, 'haar')
    _, (_, _, cD2) = coeffs2

    # Trich xuat bit tu subband HH2
    cD2_flat = cD2.flatten()
    extracted_bits = ''
    for i in range(min(len(cD2_flat), message_length * 8)):
        extracted_bits += '1' if cD2_flat[i] > 0 else '0'

    # Chuyen bit thanh van ban
    extracted_message = bits_to_text(extracted_bits)
    return extracted_message, extracted_bits

# Ham main de chay thu
if __name__ == "__main__":
    stego_image_path = 'stego_image_gray.png'  # Duong dan anh chua tin
    message_length = 30  # Do dai thong diep (30 ky tu)
    extracted_message, extracted_bits = extract_message(stego_image_path, message_length)
    print(f"Thong diep trich xuat: {extracted_message}")
    print(f"Chuoi bit trich xuat: {extracted_bits[:message_length*8]}")