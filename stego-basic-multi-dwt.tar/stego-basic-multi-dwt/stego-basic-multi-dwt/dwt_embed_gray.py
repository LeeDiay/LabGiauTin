import cv2
import numpy as np
import pywt

# Ham chuyen van ban thanh chuoi bit
def text_to_bits(text):
    bits = ''.join(format(ord(c), '08b') for c in text)
    return bits

# Ham giau tin vao subband HH2 cua DWT cap 2
def embed_message(image_path, message, output_path):
    print("Dang giau tin...")
    
    # Doc anh xam
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise Exception("Khong the doc anh")

    # Dam bao kich thuoc anh chia het cho 4 (cho DWT cap 2)
    height, width = img.shape
    if height % 4 != 0 or width % 4 != 0:
        new_height = height - (height % 4)
        new_width = width - (width % 4)
        img = img[:new_height, :new_width]
        print(f"Da cat anh ve kich thuoc ({new_height}, {new_width}) de chia het cho 4")

    # Chuyen sang float32
    img = img.astype(np.float32)

    # Ap dung DWT cap 2
    coeffs1 = pywt.dwt2(img, 'haar')
    cA1, (cH1, cV1, cD1) = coeffs1
    coeffs2 = pywt.dwt2(cA1, 'haar')
    cA2, (cH2, cV2, cD2) = coeffs2

    # Chuyen thong diep thanh bit
    message_bits = text_to_bits(message)
    print(f"Chuoi bit goc: {message_bits}")
    bit_index = 0

    # Giau tin vao subband HH2 (cD2)
    cD2_flat = cD2.flatten()
    for i in range(len(cD2_flat)):
        if bit_index < len(message_bits):
            bit = int(message_bits[bit_index])
            cD2_flat[i] = np.round(cD2_flat[i])
            if bit == 1:
                cD2_flat[i] = cD2_flat[i] + 1.0
            else:
                cD2_flat[i] = cD2_flat[i] - 1.0
            bit_index += 1
        else:
            break

    # Kiem tra xem da nhung du thong diep chua
    if bit_index < len(message_bits):
        print(f"Canh bao: Khong du he so wavelet de nhung toan bo thong diep ({bit_index}/{len(message_bits)} bit)")

    # Dua cD2_flat ve ma tran
    cD2 = cD2_flat.reshape(cD2.shape)

    # Tai tao anh tu DWT cap 2
    coeffs2_modified = (cA2, (cH2, cV2, cD2))
    cA1_modified = pywt.idwt2(coeffs2_modified, 'haar')
    coeffs1_modified = (cA1_modified, (cH1, cV1, cD1))
    img_stego = pywt.idwt2(coeffs1_modified, 'haar')

    # Cat khop kich thuoc anh goc
    img_stego = img_stego[:img.shape[0], :img.shape[1]]

    # Dam bao gia tri pixel trong khoang [0, 255]
    img_stego = np.clip(img_stego, 0, 255).astype(np.uint8)

    # Luu anh chua tin
    cv2.imwrite(output_path, img_stego, [cv2.IMWRITE_PNG_COMPRESSION, 0])

# Ham main de chay thu
if __name__ == "__main__":
    image_path = 'input_image_gray.png'  # Duong dan anh xam (PNG)
    output_path = 'stego_image_gray.png'  # Duong dan anh chua tin
    message = "Hello World! I'm PTIT student."  # Thong diep can giau
    embed_message(image_path, message, output_path)