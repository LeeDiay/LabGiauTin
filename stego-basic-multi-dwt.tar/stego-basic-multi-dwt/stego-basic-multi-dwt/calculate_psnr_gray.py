import cv2
import numpy as np
import math

# Ham tinh PSNR
def calculate_psnr(img1, img2):
    # Kiem tra va dieu chinh kich thuoc anh
    height1, width1 = img1.shape
    height2, width2 = img2.shape
    min_height = min(height1, height2)
    min_width = min(width1, width2)
    
    # Cat anh de co cung kich thuoc
    img1 = img1[:min_height, :min_width]
    img2 = img2[:min_height, :min_width]
    
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel = 255.0
    psnr = 20 * math.log10(max_pixel / math.sqrt(mse))
    return psnr

# Ham main de chay thu
if __name__ == "__main__":
    original_image_path = 'input_image_gray.png'  # Duong dan anh goc
    stego_image_path = 'stego_image_gray.png'  # Duong dan anh chua tin

    # Doc anh xam
    img_original = cv2.imread(original_image_path, cv2.IMREAD_GRAYSCALE)
    img_stego = cv2.imread(stego_image_path, cv2.IMREAD_GRAYSCALE)
    
    if img_original is None or img_stego is None:
        raise Exception("Khong the doc anh")

    # Tinh PSNR
    psnr = calculate_psnr(img_original, img_stego)
    print(f"PSNR giua anh goc va anh chua tin: {psnr:.2f} dB")